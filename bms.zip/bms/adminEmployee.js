function formHide(){
    document.getElementById('insert-form').style.display = 'none';
}

function formShow(){
    document.getElementById('insert-form').style.display = 'block';
}